#include <iostream>
#include <fstream>
#include <string>
#include <list>
#include "../HPPS/Obras.hpp"
#include "../HPPS/File_manage.hpp"

using namespace std;

list<Obras> ReadInfo()
{
    string titulo, autor, subGenero, midia; // variaveis para armazenar os valores do arquivo
    int anoPublicacao;
    list<Obras> lista; // lista para retornar os objetos lidos

    ifstream infile; 
    infile.open("TXTS/Data_bank.txt"); // abre o arquivo data_bank.txt 

    if (!infile)
    { 
        cerr << "ERROR IN FILE" << endl; // codigo de erro
    }

    while(infile >> titulo >> autor >> subGenero >> anoPublicacao >> midia){
        Obras piece(titulo, autor, subGenero, midia, anoPublicacao); 
        lista.push_back(piece);
    } // le todas as informacoes de cada objeto e adiciona a lista
    infile.close(); // fecha o arquivo

    return lista; // retorna a lista
}