#include <iostream>

int main(){

    std::cout << "Hello World!" << std::endl;
    std::cout << "Ola Mundo!" << std::endl;

    return 0;
}


