#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("Olha,\n");
    printf("Entre um pingo e outro\n");
    printf("A chuva não molha\n");
    printf("\n");
    printf("Millôr Fernandes (\"Hai-kais\", 1968)\n");

    return 0;
}