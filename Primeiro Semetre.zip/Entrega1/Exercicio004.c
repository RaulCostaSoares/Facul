#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("\"cinco\" (Jose  Lino Grunewald, 1987)\n");
    printf("\n");
    printf("1\n");
    printf("\n");
    printf("2 2\n");
    printf("\n");
    printf("3 3 3\n");
    printf("\n");
    printf("4 4 4 4\n");
    printf("\n");
    printf("c i n c o\n");

    return 0;
}