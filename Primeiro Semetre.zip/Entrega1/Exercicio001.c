#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("\"A dúvida é o princípio da sabedoria.\" (Aristóteles)\n");

    return 0;
}