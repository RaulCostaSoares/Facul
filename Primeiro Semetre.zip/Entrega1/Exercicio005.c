#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("\"Poeminho do Contra\" (Mário Quintana)\n");
    printf("\n");
    printf("Todos esses que aí estão\n");
    printf("Atravancando meu caminho,\n");
    printf("Eles passarão...\n");
    printf("Eu passarinho!\n");

    return 0;
}