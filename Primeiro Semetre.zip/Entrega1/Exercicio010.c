#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("+---------------------------------------------+\n");
    printf("| Só pelo amor o homem se realiza plenamente. |\n");
    printf("|                                      Platão |\n");
    printf("+---------------------------------------------+\n");

    return 0;
}