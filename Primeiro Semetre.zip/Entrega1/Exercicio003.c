#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("\"Velocidade\" (Ronaldo Azeredo, 1957),\n");
    printf("\n");
    printf("VVVVVVVVVV\n");
    printf("VVVVVVVVVE\n");
    printf("VVVVVVVVEL\n");
    printf("VVVVVVVELO\n");
    printf("VVVVVVELOC\n");
    printf("VVVVVELOCI\n");
    printf("VVVVELOCID\n");
    printf("VVVELOCIDA\n");
    printf("VVELOCIDAD\n");
    printf("VELOCIDADE\n");

    return 0;
}