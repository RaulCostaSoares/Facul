#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf(" ___   _   _    ___   ___   ___ \n");
    printf("| _ \\ | | | |  / __| | _ \\ / __|\n");
    printf("|  _/ | |_| | | (__  |   / \\__ \\\n");
    printf("|_|    \\___/   \\___| |_|_\\ |___/\n");

    return 0;
}