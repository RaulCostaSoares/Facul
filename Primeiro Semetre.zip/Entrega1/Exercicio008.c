#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("   __o\n");
    printf(" _ \\<_\n");
    printf("(_)/(_)\n");

    return 0;
}