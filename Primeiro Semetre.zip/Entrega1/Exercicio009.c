#include <stdio.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL,"");

    printf("  .-\"-.\n");
    printf(" /|6 6|\\\n");
    printf("{/(_O_)\\}\n");
    printf(" _/ ^ \\_\n");
    printf("(/_/^\\_\\)\n");

    return 0;
}