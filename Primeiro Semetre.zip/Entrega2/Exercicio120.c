#include <stdio.h>


int main(){

    int i, f, h;
    
    scanf("%d", &i);
    scanf("%d", &f);

    h = f-i;

    printf("%d ", h*60);

    return 0;
}