#include <stdio.h>

int main(){

    int i;
    
    for(i=11;i<=19;i=i+2){

        printf("%d ", i);
    }
    return 0;
}