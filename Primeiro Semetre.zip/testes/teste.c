#include <stdio.h>

int main(){

    int x = 2;
    double y = 200.1, out;

    out = x*y;

    printf("%d", out);


    return 0;
}